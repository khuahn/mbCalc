# mbcalc
MedBillCalc PHP
- Project purpose and features
- Setup instructions (local PHP, tunneling, etc.)
- Branding philosophy (kanji signature, layout rules)
- Security notes (CSRF, session handling)
- Screenshot or demo GIF (optional)
