  <footer class="footer">
    <small>© 2025 · jac · MedBillCalc</small>
  </footer>
</body>
</html>
